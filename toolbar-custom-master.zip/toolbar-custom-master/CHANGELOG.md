## 0.0.11 - Fix [#18](https://github.com/suda/toolbar-main/issues/18)
## 0.0.10 - :package: :arrow_up: Update tool-bar package provider service. Per [suda/tool-bar#141][].
## 0.0.2 - Added spacer before buttons
## 0.0.1 - First Release

[suda/tool-bar#141]: https://github.com/suda/tool-bar/issues/141
