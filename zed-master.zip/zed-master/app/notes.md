Welcome to your notes space
===========================

All files you'll create within this project will be stored in your Google Drive
and synced across all your computers logged in with your current Google account.

Enjoy! 